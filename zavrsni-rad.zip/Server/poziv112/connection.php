<?php
	define('hostname','127.0.0.1');
	define ('user','root');
	define ('password','');
	define ('databaseName','poziv112');
	
	$connect = mysqli_connect(hostname,user,password,databaseName);

?>